<?php
namespace app\adminer\model;

use think\Model;

class AdminMenu extends Model
{
	protected function initialize(){
		parent::initialize();
	}

	
}