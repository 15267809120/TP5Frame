<?php
namespace app\adminer\model;

use think\Model;

class Config extends Model
{
	protected function initialize(){
		parent::initialize();
	}

	
}