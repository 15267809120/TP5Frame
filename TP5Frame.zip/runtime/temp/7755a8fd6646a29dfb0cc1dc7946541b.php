<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:43:"./template/adminer/jurisdiction\search.html";i:1530870673;s:58:"E:\GitProject\TP5Frame\template\adminer\Public\header.html";i:1530844075;s:62:"E:\GitProject\TP5Frame\template\adminer\Public\header-nav.html";i:1530844075;s:56:"E:\GitProject\TP5Frame\template\adminer\Public\menu.html";i:1530946662;s:62:"E:\GitProject\TP5Frame\template\adminer\Public\breadcrumb.html";i:1530844075;s:64:"E:\GitProject\TP5Frame\template\adminer\Public\footer-table.html";i:1530844075;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>adminer</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="\public\static\admin/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="\public\static\admin/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="\public\static\admin/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- Morris chart -->
        <link href="\public\static\admin/css/morris/morris.css" rel="stylesheet" type="text/css" />
        <!-- jvectormap -->
        <link href="\public\static\admin/css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <!-- fullCalendar -->
        <link href="\public\static\admin/css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />
        <!-- Daterange picker -->
        <link href="\public\static\admin/css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
        <!-- bootstrap wysihtml5 - text editor -->
        <link href="\public\static\admin/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
        <!-- DATA TABLES -->
        <link href="\public\static\admin/css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="\public\static\admin/css/AdminLTE.css" rel="stylesheet" type="text/css" />
        

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <!-- header logo: style can be found in header.less -->
<header class="header">
            <a href="<?php echo Url('Index/index'); ?>" class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
                Adminer
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- User Account: style can be found in dropdown.less -->
                        <li class="dropdown user user-menu">
                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="glyphicon glyphicon-user"></i>
                                <span><?php echo \think\Session::get('user.nickname'); ?> <i class="caret"></i></span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- Menu Footer-->
                                <li class="user-footer">
                                    <div class="pull-right">
                                        <a href="<?php echo Url('Login/logout'); ?>" class="btn btn-default btn-flat">退出</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
<aside class="left-side sidebar-offcanvas">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">

                        <div class="pull-left info">
                            <p>Hello, <?php echo \think\Session::get('user.nickname'); ?></p>
                        </div>
                    </div>
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <li class="treeview <?php if($vo['id'] == $menu_id): ?>active<?php endif; ?>">
                            <a href="#">
                                <span><?php echo $vo['name']; ?></span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <?php if(!empty($vo['zlist'])): ?>
	                            <ul class="treeview-menu">
	                                <?php if(is_array($vo['zlist']) || $vo['zlist'] instanceof \think\Collection || $vo['zlist'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['zlist'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
	                                <li><a href="<?php echo $v['link']; ?>"><i class="fa fa-angle-double-right"></i> <?php echo $v['name']; ?></a></li>
	                                <?php endforeach; endif; else: echo "" ;endif; ?>
	                            </ul>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>
            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        <?php echo $menu_info['name']; ?>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo Url('Index/index'); ?>"><i class="fa fa-dashboard"></i> 主界面</a></li>
                        <li class="active"><?php echo $p_menu['name']; ?></li>
                        <li class="active"><?php echo $menu_info['name']; ?></li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
                            
                            <div class="box">
                                <!-- <div class="box-header">
                                    <h3 class="box-title">管理员列表</h3>
                                </div> -->
                                <div class="box-body table-responsive">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <div class="row">
                                            <div class="col-xs-2">
                                                <a href="<?php echo Url('Jurisdiction/insert'); ?>">新增</a>
                                            </div>
                                            <div class="col-xs-6">
                                                <select id="search_name">
                                                    <?php if(is_array($list_fields) || $list_fields instanceof \think\Collection || $list_fields instanceof \think\Paginator): $i = 0; $__LIST__ = $list_fields;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                                    	<option value="<?php echo $vo; ?>"><?php echo $vo; ?></option>
                                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                                </select>
                                                <input type="text" id="search_value" />
                                                <button onclick="return search();">搜索</button>
                                            </div>
                                        </div>
                                        <thead>
                                            <tr>
	                                            <?php if(is_array($list_fields) || $list_fields instanceof \think\Collection || $list_fields instanceof \think\Paginator): $i = 0; $__LIST__ = $list_fields;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
	                                                <th><?php echo $vo; ?></th>
	                                            <?php endforeach; endif; else: echo "" ;endif; ?>
	                                            <th>操作</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                            <tr>
                                                <?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                                    <td><?php echo $v; ?></td>
                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                                <td>
                                                    <button class="btn btn-info btn-sm" onclick="return update_this('<?php echo $vo['group_id']; ?>');">修改</button>
                                                    <button class="btn btn-danger btn-sm" onclick="return delete_this('<?php echo $vo['group_id']; ?>');">删除</button>
                                                </td>
                                            </tr>
                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                        </tbody>
<!--                                         <tfoot>
                                            <tr>
                                            <?php if(is_array($list_fields) || $list_fields instanceof \think\Collection || $list_fields instanceof \think\Paginator): $i = 0; $__LIST__ = $list_fields;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                                <th><?php echo $vo; ?></th>
                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                            <th>操作</th>
                                            </tr>
                                        </tfoot> -->
                                    </table>
                                    <div class="row">
                                        <div class="col-xs-6">
                                            <span id="count">总共 <?php echo $count; ?> 条数据</span>
                                        </div>
                                        <div id="page" class="col-xs-6" style="text-align: right;">
                                            <?php echo $page; ?>
                                        </div>
                                    </div>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->
        <!-- page script -->
        
    <!-- jQuery 2.1.1 -->
    <script src="\public\static\admin/js/jquery-2.1.1.min.js"></script>
    <!-- Bootstrap -->
    <script src="\public\static\admin/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- DATA TABES SCRIPT -->
    <script src="\public\static\admin/js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="\public\static\admin/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="\public\static\admin/js/AdminLTE/app.js" type="text/javascript"></script>

    <script src="\public\static\admin/js/layer/layer.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function(){
        $('.pagination').css('margin','0');
        $('#example1').dataTable({
            "bPaginate": false,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": false,
            "bAutoWidth": true,
        });
        
    });

    function update_this(id){
        var url = "<?php echo Url('Jurisdiction/update'); ?>";
        url = url.replace('.html','/group_id/'+id);
        location.href=url;
    }

    function delete_this(id){
        //询问框
        layer.confirm('确定删除吗', {
            btn: ['删除','取消'] //按钮
        }, function(){
            $.ajax({
                url:"<?php echo Url('Jurisdiction/delete'); ?>",
                datatype:'json',
                type:'post',
                data:'group_id='+id,
                success : function (result){
                    if(result.code == 'success'){
                        location.reload();
                    }
                }
            })
            
        }, function(){
            //这个空方法是取消，不要删除
        });
    }
    
    function search(){
    	var search_name = $('#search_name').val();
    	var search_value = $('#search_value').val();
    	var url = "<?php echo Url('Jurisdiction/search'); ?>";
        url = url.replace('.html','/search_name/'+search_name+'/search_value/'+search_value);
        location.href=url;
    }
    </script>
    </body>
</html>