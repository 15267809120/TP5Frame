<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:43:"./template/adminer/jurisdiction\insert.html";i:1530870591;s:58:"E:\GitProject\TP5Frame\template\adminer\Public\header.html";i:1530844075;s:62:"E:\GitProject\TP5Frame\template\adminer\Public\header-nav.html";i:1530844075;s:56:"E:\GitProject\TP5Frame\template\adminer\Public\menu.html";i:1530946662;s:62:"E:\GitProject\TP5Frame\template\adminer\Public\breadcrumb.html";i:1530844075;s:58:"E:\GitProject\TP5Frame\template\adminer\Public\footer.html";i:1530844075;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>adminer</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="\public\static\admin/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="\public\static\admin/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="\public\static\admin/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- Morris chart -->
        <link href="\public\static\admin/css/morris/morris.css" rel="stylesheet" type="text/css" />
        <!-- jvectormap -->
        <link href="\public\static\admin/css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <!-- fullCalendar -->
        <link href="\public\static\admin/css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />
        <!-- Daterange picker -->
        <link href="\public\static\admin/css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
        <!-- bootstrap wysihtml5 - text editor -->
        <link href="\public\static\admin/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
        <!-- DATA TABLES -->
        <link href="\public\static\admin/css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="\public\static\admin/css/AdminLTE.css" rel="stylesheet" type="text/css" />
        

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <!-- header logo: style can be found in header.less -->
<header class="header">
            <a href="<?php echo Url('Index/index'); ?>" class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
                Adminer
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- User Account: style can be found in dropdown.less -->
                        <li class="dropdown user user-menu">
                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="glyphicon glyphicon-user"></i>
                                <span><?php echo \think\Session::get('user.nickname'); ?> <i class="caret"></i></span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- Menu Footer-->
                                <li class="user-footer">
                                    <div class="pull-right">
                                        <a href="<?php echo Url('Login/logout'); ?>" class="btn btn-default btn-flat">退出</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
<aside class="left-side sidebar-offcanvas">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">

                        <div class="pull-left info">
                            <p>Hello, <?php echo \think\Session::get('user.nickname'); ?></p>
                        </div>
                    </div>
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <li class="treeview <?php if($vo['id'] == $menu_id): ?>active<?php endif; ?>">
                            <a href="#">
                                <span><?php echo $vo['name']; ?></span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <?php if(!empty($vo['zlist'])): ?>
	                            <ul class="treeview-menu">
	                                <?php if(is_array($vo['zlist']) || $vo['zlist'] instanceof \think\Collection || $vo['zlist'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['zlist'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
	                                <li><a href="<?php echo $v['link']; ?>"><i class="fa fa-angle-double-right"></i> <?php echo $v['name']; ?></a></li>
	                                <?php endforeach; endif; else: echo "" ;endif; ?>
	                            </ul>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        <?php echo $menu_info['name']; ?>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo Url('Index/index'); ?>"><i class="fa fa-dashboard"></i> 主界面</a></li>
                        <li class="active"><?php echo $p_menu['name']; ?></li>
                        <li class="active"><?php echo $menu_info['name']; ?></li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <!-- left column -->
                        <div class="col-md-8">
                            <!-- general form elements -->
                            <div class="box box-primary">
                                <div class="box-header">
                                    <h3 class="box-title">新增权限组</h3>
                                </div>
                                <!-- form start -->
                                <form role="form" id="form">
                                    <div class="box-body">
                                    <?php if(is_array($list_fields) || $list_fields instanceof \think\Collection || $list_fields instanceof \think\Paginator): $i = 0; $__LIST__ = $list_fields;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                        <div class="form-group">
                                            <label for="<?php echo $vo; ?>"><?php echo $vo; ?></label>
                                            <input type="text" class="form-control" id="<?php echo $vo; ?>" name="<?php echo $vo; ?>" placeholder="请输入<?php echo $vo; ?>">
                                        </div>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                        <div class="form-group">
                                            <label for="jurisdiction">jurisdiction</label>
                                            <div class="checkbox">
                                            <?php if(is_array($menu_list) || $menu_list instanceof \think\Collection || $menu_list instanceof \think\Paginator): $i = 0; $__LIST__ = $menu_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                                <label>
                                                    <input type="checkbox" name="id-<?php echo $vo['id']; ?>" value="1" />
                                                    <?php echo $vo['name']; ?>
                                                </label>
                                                <?php if(!empty($vo['zlist'])): ?>
                                                    <div style="text-indent:4em;">
                                                        <?php if(is_array($vo['zlist']) || $vo['zlist'] instanceof \think\Collection || $vo['zlist'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['zlist'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
	                                                        <label>
	                                                            <input type="checkbox" name="id-<?php echo $v['id']; ?>" value="1" />
	                                                            <?php echo $v['name']; ?>
	                                                        </label>
	                                                        <?php if(!empty($v['zlist'])): ?>
			                                                    <div style="text-indent:8em;">
			                                                        <?php if(is_array($v['zlist']) || $v['zlist'] instanceof \think\Collection || $v['zlist'] instanceof \think\Paginator): $i = 0; $__LIST__ = $v['zlist'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vl): $mod = ($i % 2 );++$i;?>
			                                                        <label>
			                                                            <input type="checkbox" name="id-<?php echo $vl['id']; ?>" value="1" />
			                                                            <?php echo $vl['name']; ?>
			                                                        </label>
			                                                        <?php endforeach; endif; else: echo "" ;endif; ?>
			                                                    </div>
			                                                <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                                <div style="margin-bottom: 30px;"></div>
                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                            </div>
                                        </div>

                                    </div><!-- /.box-body -->

                                    <div class="box-footer">
                                        <button type="submit" class="btn btn-primary" onclick="return ajax_submit();">提交</button>
                                    </div>
                                </form>
                            </div><!-- /.box -->

                        </div><!--/.col (left) -->
                        
                    </div>   <!-- /.row -->
                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->
        <script type="text/javascript">
            function ajax_submit(){
                var name = $('#name').val();
                var get_data = $('#form').serialize();
                var error = '';
                if(name == '') error = '请输入权限组名字';
                if(get_data.indexOf('id-') === -1) error = '请选择权限';
                if(error != ''){
                    layer.msg(error);
                    return false;
                }
                $.ajax({
                    url:"<?php echo Url('Jurisdiction/insert'); ?>",
                    datatype:'json',
                    type:'post',
                    data:$('#form').serialize(),
                    success : function (result){
                        if(result.code == 'success'){
                            location.href="<?php echo Url('Jurisdiction/grouplist'); ?>";
                        }else if(result.code == 'error'){
                        	layer.msg(result.str);
                        }
                    }
                })
                return false;
            }
        </script>
    <!-- jQuery 2.1.1 -->
        <script src="\public\static\admin/js/jquery-2.1.1.min.js"></script>
        <!-- jQuery UI 1.10.3 -->
        <script src="\public\static\admin/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="\public\static\admin/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- Morris.js charts -->
        <script src="\public\static\admin/js/raphael-min.js"></script>
        <script src="\public\static\admin/js/plugins/morris/morris.min.js" type="text/javascript"></script>
        <!-- Sparkline -->
        <script src="\public\static\admin/js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
        <!-- jvectormap -->
        <script src="\public\static\admin/js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
        <script src="\public\static\admin/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
        <!-- fullCalendar -->
        <script src="\public\static\admin/js/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
        <!-- jQuery Knob Chart -->
        <script src="\public\static\admin/js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
        <!-- daterangepicker -->
        <script src="\public\static\admin/js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="\public\static\admin/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
        <!-- iCheck -->
        <script src="\public\static\admin/js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>

        <!-- AdminLTE App -->
        <script src="\public\static\admin/js/AdminLTE/app.js" type="text/javascript"></script>
        
        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        <script src="\public\static\admin/js/AdminLTE/dashboard.js" type="text/javascript"></script>
        <script src="\public\static\admin/js/layer/layer.js" type="text/javascript"></script>

        

    </body>
</html>